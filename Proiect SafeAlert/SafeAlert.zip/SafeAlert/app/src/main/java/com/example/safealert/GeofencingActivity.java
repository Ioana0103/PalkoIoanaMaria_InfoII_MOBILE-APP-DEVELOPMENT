package com.example.safealert;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.HashMap;
import java.util.Map;

public class GeofencingActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final int PERMISSION_REQUEST_CODE = 101;
    private FusedLocationProviderClient fusedLocationClient;
    private TextView tvGeo;
    private Spinner spinnerZones;
    private GoogleMap map;
    private Marker marker;
    private Circle circle;
    private final float safeRadius = 200;

    private final Map<String, LatLng> safeZones = new HashMap<>();
    private final String[] emergencyContacts = {"0760123456", "0760654321"};

    private boolean isOutside = false;
    private MediaPlayer mediaPlayer;
    private Handler locationUpdateHandler;
    private Runnable locationUpdateRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_geofencing);

        tvGeo = findViewById(R.id.tv_geo);
        spinnerZones = findViewById(R.id.spinner_zones);
        Button btnCheckZone = findViewById(R.id.btn_check_zone);
        Button btnBack = findViewById(R.id.btn_back);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        safeZones.put("Scoala", new LatLng(46.5471796, 24.5682440));
        safeZones.put("Acasa", new LatLng(46.5500000, 24.5650000));
        safeZones.put("Birou", new LatLng(46.5450000, 24.5700000));

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, safeZones.keySet().toArray(new String[0]));
        spinnerZones.setAdapter(adapter);

        btnCheckZone.setOnClickListener(v -> checkGeofence());
        btnBack.setOnClickListener(v -> finish());

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) mapFragment.getMapAsync(this);

        requestPermissions();
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.SEND_SMS},
                PERMISSION_REQUEST_CODE);
    }

    private void checkGeofence() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) return;

        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                checkGeofenceWithLocation(location);
            }
        });
    }

    private void checkGeofenceWithLocation(Location location) {
        String selectedZone = spinnerZones.getSelectedItem().toString();
        LatLng safeLatLng = safeZones.get(selectedZone);

        float[] result = new float[1];
        Location.distanceBetween(location.getLatitude(), location.getLongitude(),
                safeLatLng.latitude, safeLatLng.longitude, result);

        LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());

        if (marker != null) marker.remove();
        marker = map.addMarker(new MarkerOptions().position(currentLatLng).title("Tu esti aici"));
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 16f));

        if (circle != null) circle.remove();
        circle = map.addCircle(new CircleOptions()
                .center(safeLatLng)
                .radius(safeRadius)
                .strokeColor(0x5500ff00)
                .fillColor(0x2200ff00));

        if (result[0] > safeRadius) {
            String alert = "⚠️ Ai iesit din zona: " + selectedZone;
            tvGeo.setText(alert);

            if (!isOutside) {
                isOutside = true;
                playAlertSound();
            }

            sendEmergencySMS(location);

        } else {
            tvGeo.setText("✔️ Esti in zona sigura: " + selectedZone);
            if (isOutside) {
                isOutside = false;
                stopAlertSound();
                stopLiveTracking();
            }
        }
    }

    private void playAlertSound() {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI);
            mediaPlayer.setLooping(true);
            mediaPlayer.start();
        }
    }

    private void stopAlertSound() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    private void sendEmergencySMS(Location location) {
        String link = "https://maps.google.com/?q=" + location.getLatitude() + "," + location.getLongitude();
        String message = "Am iesit din zona sigura! Pozitia mea: " + link;

        SmsManager smsManager = SmsManager.getDefault();
        for (String number : emergencyContacts) {
            smsManager.sendTextMessage(number, null, message, null, null);
        }

        Toast.makeText(this, "SMS de alerta trimis!", Toast.LENGTH_SHORT).show();
    }

    private void startLiveTracking() {
        locationUpdateHandler = new Handler();
        locationUpdateRunnable = new Runnable() {
            @Override
            public void run() {
                if (ActivityCompat.checkSelfPermission(GeofencingActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
                    fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
                        if (location != null) {
                            checkGeofenceWithLocation(location);
                        }
                    });
                }
                locationUpdateHandler.postDelayed(this, 60000);
            }
        };
        locationUpdateHandler.post(locationUpdateRunnable);
    }

    private void stopLiveTracking() {
        if (locationUpdateHandler != null && locationUpdateRunnable != null) {
            locationUpdateHandler.removeCallbacks(locationUpdateRunnable);
            locationUpdateHandler = null;
            locationUpdateRunnable = null;
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.map = googleMap;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            map.setMyLocationEnabled(true);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permisiuni acordate!", Toast.LENGTH_SHORT).show();
            } else {
                new AlertDialog.Builder(this)
                        .setTitle("Permisiuni necesare")
                        .setMessage("Trebuie sa permiti locatia si trimiterea de SMS-uri pentru a folosi aceasta functie.")
                        .setPositiveButton("OK", null)
                        .show();
            }
        }
    }
}