package com.example.safealert;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class EmergencyCallActivity extends AppCompatActivity {

    private static final int REQUEST_CALL_PERMISSION = 101;
    private CountDownTimer countDownTimer;
    private TextView tvTimer;
    private Button btnCancel;
    private final String emergencyNumber = "0753025412";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_call);

        tvTimer = findViewById(R.id.tv_timer);
        btnCancel = findViewById(R.id.btn_cancel);

        startCountdown();

        btnCancel.setOnClickListener(v -> {
            if (countDownTimer != null) {
                countDownTimer.cancel();
                Toast.makeText(this, "Apelul a fost anulat.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        Button btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(EmergencyCallActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

    }

    private void startCountdown() {
        countDownTimer = new CountDownTimer(10000, 1000) {
            public void onTick(long millisUntilFinished) {
                tvTimer.setText("Apel in " + (millisUntilFinished / 1000) + " secunde...");
            }

            public void onFinish() {
                makeEmergencyCall();
            }
        }.start();
    }

    private void makeEmergencyCall() {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + emergencyNumber));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL_PERMISSION);
        } else {
            startActivity(callIntent);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CALL_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            makeEmergencyCall();
        } else {
            Toast.makeText(this, "Permisiunea de apel este necesara!", Toast.LENGTH_SHORT).show();
        }
    }
}
