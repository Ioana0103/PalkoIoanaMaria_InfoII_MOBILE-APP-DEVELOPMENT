package com.example.safealert;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Location;
import android.os.BatteryManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class BatteryReceiver extends BroadcastReceiver {

    private final String[] emergencyContacts = {"0760123456", "0760654321"};

    @Override
    public void onReceive(Context context, Intent intent) {
        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);

        if (level != -1 && level <= 10) {
            Toast.makeText(context, "⚠️ Baterie scazuta: " + level + "%", Toast.LENGTH_LONG).show();

            suggestBatterySaver(context);

            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                            == android.content.pm.PackageManager.PERMISSION_GRANTED) {

                FusedLocationProviderClient locationClient = LocationServices.getFusedLocationProviderClient(context);
                locationClient.getLastLocation().addOnSuccessListener(location -> {
                    if (location != null) {
                        String url = "https://maps.google.com/?q=" + location.getLatitude() + "," + location.getLongitude();
                        Log.d("BATTERY", "URL locatie: " + url);

                        String mesaj = "⚠️ Bateria este sub 10%. Locatia mea: " + url;

                        SmsManager smsManager = SmsManager.getDefault();
                        for (String number : emergencyContacts) {
                            smsManager.sendTextMessage(number, null, mesaj, null, null);
                        }

                        Toast.makeText(context, "📩 SMS trimis catre contactele de urgenta!", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                Log.e("BATTERY", "Permisiuni lipsa pentru locatie/SMS.");
            }

            Intent i = new Intent(context, FinalLocationActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);

            Log.d("BATTERY", "Am pornit FinalLocationActivity");
        }
    }

    private void suggestBatterySaver(Context context) {
        Intent powerIntent = new Intent(Intent.ACTION_POWER_USAGE_SUMMARY);
        powerIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(powerIntent);
        } catch (Exception e) {
            Log.e("BATTERY", "Nu s-a putut deschide setarea de economisire a energiei.");
        }
    }

    public static void checkBatteryLevel(Context context) {
        Intent batteryStatus = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int percentage = (int) ((level / (float) scale) * 100);

        Toast.makeText(context, "🔋 Nivel baterie: " + percentage + "%", Toast.LENGTH_SHORT).show();

        //testare fortata
        if (percentage <= 100) {
            Intent fakeIntent = new Intent();
            fakeIntent.putExtra(BatteryManager.EXTRA_LEVEL, 5);
            new BatteryReceiver().onReceive(context, fakeIntent);
        }
    }
}
