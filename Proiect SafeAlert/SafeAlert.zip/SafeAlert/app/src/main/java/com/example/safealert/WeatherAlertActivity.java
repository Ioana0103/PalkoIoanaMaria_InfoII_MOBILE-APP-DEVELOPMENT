package com.example.safealert;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import org.json.JSONObject;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WeatherAlertActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST = 1;
    private TextView tvWeather;
    private FusedLocationProviderClient fusedLocationClient;

    private final String apiKey = "cd81a77d02c42441ed0bdc376d638193";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_alert);

        tvWeather = findViewById(R.id.tv_weather);
        Button btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(v -> {
            startActivity(new Intent(WeatherAlertActivity.this, MainActivity.class));
            finish();
        });

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST);
        } else {
            getWeatherForCurrentLocation();
        }
    }

    private void getWeatherForCurrentLocation() {
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {

                LocationRequest locationRequest = LocationRequest.create()
                        .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                        .setInterval(1000)
                        .setFastestInterval(500);

                LocationCallback locationCallback = new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {
                        Location location = locationResult.getLastLocation();
                        if (location != null) {
                            Log.d("LOCATIE", "Lat: " + location.getLatitude() + " | Lon: " + location.getLongitude());
                            fetchWeather(location);
                            fusedLocationClient.removeLocationUpdates(this);
                        } else {
                            tvWeather.setText("Nu s-a putut obtine locatia (null).");
                        }
                    }
                };

                fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);

            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        LOCATION_PERMISSION_REQUEST);
            }
        } catch (SecurityException e) {
            e.printStackTrace();
            tvWeather.setText("Eroare la obtinerea locatiei.");
        }
    }

    private void fetchWeather(Location location) {
        double lat = location.getLatitude();
        double lon = location.getLongitude();

        String apiUrl = "https://api.openweathermap.org/data/2.5/weather?lat=" + lat +
                "&lon=" + lon + "&appid=" + apiKey + "&units=metric&lang=ro";

        new FetchWeatherTask().execute(apiUrl);

        Log.d("LOCATIE", "Lat: " + lat + " | Lon: " + lon);
        Toast.makeText(this, "Lat: " + lat + "\nLon: " + lon, Toast.LENGTH_LONG).show();
    }

    private class FetchWeatherTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.connect();

                InputStreamReader reader = new InputStreamReader(conn.getInputStream());
                StringBuilder result = new StringBuilder();
                int data;
                while ((data = reader.read()) != -1) {
                    result.append((char) data);
                }

                return result.toString();
            } catch (Exception e) {
                Log.e("WEATHER", "Eroare la cerere API", e);
                return null;
            }
        }

        @Override
        protected void onPostExecute(String json) {
            if (json != null) {
                try {
                    JSONObject obj = new JSONObject(json);
                    String weatherMain = obj.getJSONArray("weather").getJSONObject(0).getString("main");
                    String description = obj.getJSONArray("weather").getJSONObject(0).getString("description");
                    double temp = obj.getJSONObject("main").getDouble("temp");

                    String rezultat = "🌤️ Vremea curenta: " + description + "\n🌡️ Temperatura: " + temp + "°C";
                    tvWeather.setText(rezultat);

                    if (isSevereWeather(weatherMain)) {
                        sendWeatherAlertSMS(description);
                    }

                } catch (Exception e) {
                    tvWeather.setText("Eroare la procesarea datelor meteo.");
                }
            } else {
                tvWeather.setText("Nu s-a putut obtine vremea.");
            }
        }

        private boolean isSevereWeather(String main) {
            String[] severe = {"Thunderstorm", "Extreme", "Tornado", "Ash", "Sand", "Dust"};
            for (String condition : severe) {
                if (main.equalsIgnoreCase(condition)) {
                    return true;
                }
            }
            return false;
        }

        private void sendWeatherAlertSMS(String description) {
            String[] emergencyContacts = {"0760123456", "0760654321"};
            String message = "⚠️ ALERTA METEO: " + description + ". Verifica starea vremii si ramai în siguranta!";

            if (ActivityCompat.checkSelfPermission(WeatherAlertActivity.this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(WeatherAlertActivity.this, "Permisiune SMS necesara!", Toast.LENGTH_SHORT).show();
                return;
            }

            SmsManager smsManager = SmsManager.getDefault();
            for (String number : emergencyContacts) {
                smsManager.sendTextMessage(number, null, message, null, null);
            }

            Toast.makeText(WeatherAlertActivity.this, "SMS de avertizare meteo trimis!", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getWeatherForCurrentLocation();
        } else {
            Toast.makeText(this, "Permisiunea locatiei este necesara!", Toast.LENGTH_SHORT).show();
        }
    }
}
