package com.example.safealert;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class InactivityService extends Service implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private boolean isMoving = false;
    private CountDownTimer inactivityTimer;

    private FusedLocationProviderClient fusedLocationClient;
    private final String[] emergencyContacts = {"0760123456", "0760654321"};

    private static final String CHANNEL_ID = "inactivity_channel";
    private static final int NOTIFICATION_ID = 1001;

    @Override
    public void onCreate() {
        super.onCreate();

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }

        showForegroundNotification("🕒 Timp ramas: 10:00");
        startInactivityTimer();
    }

    private void showForegroundNotification(String mesaj) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Monitorizare Inactivitate",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.enableVibration(true);
            channel.setImportance(NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("SafeAlert")
                .setContentText(mesaj)
                .setSmallIcon(android.R.drawable.ic_popup_sync)
                .setOngoing(true)
                .build();

        startForeground(NOTIFICATION_ID, notification);
    }


    private void startInactivityTimer() {
        inactivityTimer = new CountDownTimer(600000, 1000) {
            public void onTick(long millisUntilFinished) {
                if (isMoving) {
                    isMoving = false;
                    cancel();
                    startInactivityTimer();
                    return;
                }

                long minutes = millisUntilFinished / 60000;
                long seconds = (millisUntilFinished % 60000) / 1000;
                String time = String.format("🕒 Timp rămas: %02d:%02d", minutes, seconds);
                showForegroundNotification(time);
            }

            public void onFinish() {
                showForegroundNotification("⚠️ Timpul a expirat!");
                sendInactivityAlert();
            }
        }.start();
    }


    private void sendInactivityAlert() {
        Toast.makeText(getApplicationContext(), "⚠️ Inactivitate detectata!", Toast.LENGTH_LONG).show();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Log.e("INACTIVITY", "Permisiuni lipsa pentru locatie sau SMS.");
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                String link = "https://maps.google.com/?q=" + location.getLatitude() + "," + location.getLongitude();
                String message = "⚠️ Nu am mai fost activ de 10 minute. Locatia mea este: " + link;

                SmsManager smsManager = SmsManager.getDefault();
                for (String number : emergencyContacts) {
                    smsManager.sendTextMessage(number, null, message, null, null);
                }

                Log.d("INACTIVITY", "SMS trimis catre contacte de urgenta.");
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (accelerometer != null) {
            sensorManager.unregisterListener(this);
        }
        if (inactivityTimer != null) {
            inactivityTimer.cancel();
        }
        stopForeground(true);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0], y = event.values[1], z = event.values[2];
        double acceleration = Math.sqrt(x * x + y * y + z * z);
        if (acceleration > 1.5) {
            isMoving = true;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
