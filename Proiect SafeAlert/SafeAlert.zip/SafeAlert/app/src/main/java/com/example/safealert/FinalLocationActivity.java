package com.example.safealert;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class FinalLocationActivity extends AppCompatActivity {

    private final String[] emergencyContacts = {"0760123456", "0760654321"};
    private FusedLocationProviderClient fusedLocationClient;
    private TextView tvFinalStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_location);

        tvFinalStatus = findViewById(R.id.tv_final_status);
        Button btnSendLocation = findViewById(R.id.btn_send_final_location);
        Button btnBack = findViewById(R.id.btn_back);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        btnSendLocation.setOnClickListener(v -> sendFinalLocation());

        btnBack.setOnClickListener(v -> finish());
    }

    private void sendFinalLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permisiuni lipsa!", Toast.LENGTH_SHORT).show();
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                String link = "https://maps.google.com/?q=" + location.getLatitude() + "," + location.getLongitude();
                String mesaj = "📍 Ultima mea locatie (baterie scazuta): " + link;

                SmsManager smsManager = SmsManager.getDefault();
                for (String contact : emergencyContacts) {
                    smsManager.sendTextMessage(contact, null, mesaj, null, null);
                }

                tvFinalStatus.setText("✅ Locatia a fost trimisa.");
                Toast.makeText(this, "SMS-uri trimise catre contacte favorite!", Toast.LENGTH_SHORT).show();
            } else {
                tvFinalStatus.setText("❌ Locatia nu a fost obtinuta.");
            }
        });
    }
}
