package com.example.safealert;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MessageSchedulerActivity extends AppCompatActivity {

    private CountDownTimer timer;
    private TextView tvStatus;
    private Spinner spinnerMessage, spinnerTime;
    private final String[] emergencyContacts = {"0760123456", "0760654321", "0753025412"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_scheduler);

        tvStatus = findViewById(R.id.tv_status);
        spinnerMessage = findViewById(R.id.spinner_message);
        spinnerTime = findViewById(R.id.spinner_time);
        Button btnCancel = findViewById(R.id.btn_cancel_msg);
        Button btnBack = findViewById(R.id.btn_back);

        String[] messages = {
                "Am plecat intr-o drumetie, daca nu raspund in 10 minute, inseamna ca sunt in pericol.",
                "Sunt in taxi, ar trebui sa ajung acasa in 5 minute.",
                "Verifica daca sunt ok, nu am raspuns de ceva timp."
        };

        String[] times = {"1 minut", "5 minute", "10 minute", "30 minute"};

        spinnerMessage.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, messages));
        spinnerTime.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, times));

        startScheduledMessage();

        btnCancel.setOnClickListener(v -> {
            if (timer != null) timer.cancel();
            Toast.makeText(this, "Mesajul a fost anulat.", Toast.LENGTH_SHORT).show();
            finish();
        });

        btnBack.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    private void startScheduledMessage() {
        int[] durations = {60000, 300000, 600000, 1800000};

        spinnerTime.post(() -> {
            int index = spinnerTime.getSelectedItemPosition();
            long duration = durations[index];

            timer = new CountDownTimer(duration, 1000) {
                public void onTick(long millisUntilFinished) {
                    long minutes = millisUntilFinished / 60000;
                    long seconds = (millisUntilFinished % 60000) / 1000;
                    tvStatus.setText("⏱️ Mesajul va fi trimis in " + minutes + "m " + seconds + "s");
                }

                public void onFinish() {
                    String msg = spinnerMessage.getSelectedItem().toString();
                    sendSMS(msg);
                }
            }.start();
        });
    }

    private void sendSMS(String message) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permisiune SMS necesara!", Toast.LENGTH_SHORT).show();
            return;
        }

        SmsManager smsManager = SmsManager.getDefault();
        for (String number : emergencyContacts) {
            smsManager.sendTextMessage(number, null, message, null, null);
        }

        Toast.makeText(this, "📩 Mesaj programat trimis!", Toast.LENGTH_LONG).show();
        Log.d("MSG_PROGRAMAT", "Trimis: " + message);
        finish();
    }
}
