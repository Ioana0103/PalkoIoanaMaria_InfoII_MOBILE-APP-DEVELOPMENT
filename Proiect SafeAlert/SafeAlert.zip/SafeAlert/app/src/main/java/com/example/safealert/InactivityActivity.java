package com.example.safealert;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class InactivityActivity extends AppCompatActivity {

    private TextView tvTimer;
    private CountDownTimer uiTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inactivity);

        Button btnStart = findViewById(R.id.btn_start_monitor);
        Button btnStop = findViewById(R.id.btn_stop_monitor);
        Button btnBack = findViewById(R.id.btn_back);
        tvTimer = findViewById(R.id.tv_timer);

        btnStart.setOnClickListener(v -> {
            startService(new Intent(this, InactivityService.class));
            startUiTimer();
        });

        btnStop.setOnClickListener(v -> {
            stopService(new Intent(this, InactivityService.class));
            stopUiTimer();
            tvTimer.setText("⏱️ Timp ramas: --:--");
        });

        btnBack.setOnClickListener(v -> {
            stopUiTimer();
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    private void startUiTimer() {
        stopUiTimer();

        uiTimer = new CountDownTimer(600000, 1000) {
            public void onTick(long millisUntilFinished) {
                long minutes = millisUntilFinished / 60000;
                long seconds = (millisUntilFinished % 60000) / 1000;
                String time = String.format("⏱️ Timp ramas: %02d:%02d", minutes, seconds);
                tvTimer.setText(time);
            }

            public void onFinish() {
                tvTimer.setText("⚠️ Timpul a expirat!");
            }
        }.start();
    }

    private void stopUiTimer() {
        if (uiTimer != null) {
            uiTimer.cancel();
            uiTimer = null;
        }
    }
}
