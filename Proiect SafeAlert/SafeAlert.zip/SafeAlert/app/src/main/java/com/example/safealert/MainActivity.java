package com.example.safealert;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnSos, btnCall, btnBattery, btnMsg, btnWeather, btnInactivity, btnGeo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSos = findViewById(R.id.btn_sos);
        btnCall = findViewById(R.id.btn_call);
        btnBattery = findViewById(R.id.btn_battery);
        btnMsg = findViewById(R.id.btn_msg);
        btnWeather = findViewById(R.id.btn_weather);
        btnInactivity = findViewById(R.id.btn_inactivity);
        btnGeo = findViewById(R.id.btn_geo);

        btnSos.setOnClickListener(v -> startActivity(new Intent(this, SosActivity.class)));
        btnCall.setOnClickListener(v -> startActivity(new Intent(this, EmergencyCallActivity.class)));
        btnBattery.setOnClickListener(v -> BatteryReceiver.checkBatteryLevel(MainActivity.this));
        btnMsg.setOnClickListener(v -> startActivity(new Intent(this, MessageSchedulerActivity.class)));
        btnWeather.setOnClickListener(v -> startActivity(new Intent(this, WeatherAlertActivity.class)));
        btnInactivity.setOnClickListener(v -> startActivity(new Intent(this, InactivityActivity.class)));
        btnGeo.setOnClickListener(v -> startActivity(new Intent(this, GeofencingActivity.class)));
    }
}
